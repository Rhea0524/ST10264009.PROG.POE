﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace RecipeAppWPF
{
    //code attribution
    //this code was taken from: https://learn.microsoft.com/en-us/dotnet/desktop/wpf/data/how-to-filter-data-in-a-view?view=netframeworkdesktop-4.8
    public partial class FilterWindow : Window
    {
        private List<Recipe> recipes; // Assuming this is where your recipes list is defined
        private List<Recipe> filteredRecipes;

        public string IngredientName => textBoxIngredientFilter.Text;

        public int MaxCalories
        {
            get
            {
                if (int.TryParse(MaxCaloriesTextBox.Text, out int calories))
                {
                    return calories;
                }
                return 0;
            }
        }

        public FilterWindow(List<Recipe> recipes)
        {
            InitializeComponent();
            WindowState = WindowState.Maximized;
            this.recipes = recipes; // Initialize the recipes list
        }

        private void ButtonFilter_Click(object sender, RoutedEventArgs e)
        {
            filteredRecipes = recipes;

            if (radioButtonIngredient.IsChecked == true)
            {
                string ingredient = textBoxIngredientFilter.Text;
                filteredRecipes = recipes.Where(r => r.Ingredients.Any(i => i.Name.IndexOf(ingredient, StringComparison.OrdinalIgnoreCase) >= 0)).ToList();
            }
            else if (radioButtonFoodGroup.IsChecked == true)
            {
                string foodGroup = textBoxFoodGroupFilter.Text;
                filteredRecipes = recipes.Where(r => r.Ingredients.Any(i => i.FoodGroup.IndexOf(foodGroup, StringComparison.OrdinalIgnoreCase) >= 0)).ToList();
            }
            else if (radioButtonCalories.IsChecked == true)
            {
                if (int.TryParse(MaxCaloriesTextBox.Text, out int maxCalories))
                {
                    filteredRecipes = recipes.Where(r => r.Ingredients.Sum(i => i.Calories) <= maxCalories).ToList();
                }
                else
                {
                    MessageBox.Show("Please enter a valid number for calories.");
                    return;
                }
            }

            if (filteredRecipes.Count == 0)
            {
                MessageBox.Show("No recipes meet the requirements.");
            }

            ListViewRecipes.ItemsSource = filteredRecipes;
        }

        private void SelectButton_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            Recipe selectedRecipe = button.DataContext as Recipe;

            // Open the RecipeDetailsWindow to display the selected recipe details
            RecipeDetailsWindow recipeDetailsWindow = new RecipeDetailsWindow(selectedRecipe);
            recipeDetailsWindow.ShowDialog();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            // Close the window without applying filters
            DialogResult = false;
            Close();
        }

        private void ListViewRecipes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ListViewRecipes_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
