﻿using System.Collections.Generic;

namespace RecipeAppWPF
{
    /// <summary>
    /// Static class to manage the collection of recipes.
    /// </summary>
    public static class RecipeManager
    {
        /// <summary>
        /// List to store all recipes.
        /// </summary>
        public static List<Recipe> recipes = new List<Recipe>();

        /// <summary>
        /// Adds a new recipe to the collection.
        /// </summary>
        /// <param name="recipe">The recipe to add.</param>
        public static void AddRecipe(Recipe recipe)
        {
            recipes.Add(recipe);
        }

        /// <summary>
        /// Removes a recipe from the collection.
        /// </summary>
        /// <param name="recipe">The recipe to remove.</param>
        public static void RemoveRecipe(Recipe recipe)
        {
            recipes.Remove(recipe);
        }

        /// <summary>
        /// Retrieves a copy of all recipes currently in the collection.
        /// </summary>
        /// <returns>A list containing all recipes.</returns>
        public static List<Recipe> GetAllRecipes()
        {
            return new List<Recipe>(recipes);
        }
    }
}
