﻿using System.Windows;
using System.Windows.Controls;

namespace RecipeAppWPF
{
    public partial class RecipeDetailsWindow : Window
    {
        public RecipeDetailsWindow(Recipe recipe)
        {
            InitializeComponent();
            LoadRecipeDetails(recipe);
            WindowState = WindowState.Maximized;
        }

        private void LoadRecipeDetails(Recipe recipe)
        {
            // Clear previous content
            RecipeDetailsStackPanel.Children.Clear();

            // Display the name of the recipe
            TextBlock recipeNameTextBlock = new TextBlock
            {
                Text = recipe.Name,
                FontSize = 24,
                FontWeight = FontWeights.Bold,
                Foreground = System.Windows.Media.Brushes.Black,
                TextAlignment = TextAlignment.Center,
                Margin = new Thickness(0, 20, 0, 20),
                TextDecorations = TextDecorations.Underline
            };

            RecipeDetailsStackPanel.Children.Add(recipeNameTextBlock);

            // Display the number of ingredients
            TextBlock ingredientCountTextBlock = new TextBlock
            {
                Text = $"Ingredients ({recipe.Ingredients.Count}):",
                FontSize = 20,
                FontWeight = FontWeights.Bold,
                Foreground = System.Windows.Media.Brushes.Black,
                Margin = new Thickness(0, 10, 0, 10),
                TextDecorations = TextDecorations.Underline
            };
            RecipeDetailsStackPanel.Children.Add(ingredientCountTextBlock);

            // Display ingredient details
            foreach (var ingredient in recipe.Ingredients)
            {
                Border ingredientBorder = new Border
                {
                    Background = System.Windows.Media.Brushes.WhiteSmoke,
                    CornerRadius = new CornerRadius(5),
                    BorderThickness = new Thickness(1),
                    BorderBrush = System.Windows.Media.Brushes.Gray,
                    Margin = new Thickness(0, 5, 0, 5),
                    Padding = new Thickness(10)
                };

                StackPanel ingredientPanel = new StackPanel
                {
                    Orientation = Orientation.Vertical
                };

                TextBlock ingredientNameTextBlock = new TextBlock
                {
                    Text = ingredient.Name,
                    FontSize = 18,
                    FontWeight = FontWeights.Bold,
                    Foreground = System.Windows.Media.Brushes.Black,
                    Margin = new Thickness(0, 0, 0, 5)
                };
                ingredientPanel.Children.Add(ingredientNameTextBlock);

                TextBlock ingredientDetailsTextBlock = new TextBlock
                {
                    Text = $"Measurement: {ingredient.Measurement} {ingredient.Unit}, Calories: {ingredient.Calories}, Food Group: {ingredient.FoodGroup}",
                    FontSize = 16,
                    Foreground = System.Windows.Media.Brushes.Black,
                    Margin = new Thickness(0, 0, 0, 5)
                };
                ingredientPanel.Children.Add(ingredientDetailsTextBlock);

                ingredientBorder.Child = ingredientPanel;
                RecipeDetailsStackPanel.Children.Add(ingredientBorder);
            }

            // Calculate total calories
            int totalCalories = recipe.Ingredients.Sum(i => i.Calories);

            // Display total calories
            TextBlock totalCaloriesTextBlock = new TextBlock
            {
                Text = $"Total Calories: {totalCalories}",
                FontSize = 18,
                FontWeight = FontWeights.Bold,
                Foreground = System.Windows.Media.Brushes.Black,
                Margin = new Thickness(0, 20, 0, 5)
            };
            RecipeDetailsStackPanel.Children.Add(totalCaloriesTextBlock);

            // Display the warning if calories exceed 300
            if (totalCalories > 300)
            {
                TextBlock warningTextBlock = new TextBlock
                {
                    Text = "Warning: Recipe exceeds 300 calories",
                    FontSize = 16,
                    FontWeight = FontWeights.Bold,
                    Foreground = System.Windows.Media.Brushes.Red,
                    Margin = new Thickness(0, 5, 0, 20)
                };
                RecipeDetailsStackPanel.Children.Add(warningTextBlock);
            }

            // Display the number of steps
            TextBlock stepCountTextBlock = new TextBlock
            {
                Text = $"Steps ({recipe.Steps.Count}):",
                FontSize = 20,
                FontWeight = FontWeights.Bold,
                Foreground = System.Windows.Media.Brushes.Black,
                Margin = new Thickness(0, 20, 0, 10),
                TextDecorations = TextDecorations.Underline
            };
            RecipeDetailsStackPanel.Children.Add(stepCountTextBlock);

            // Display each step with a checkbox
            int stepIndex = 1;
            foreach (var step in recipe.Steps)
            {
                Border stepBorder = new Border
                {
                    Background = System.Windows.Media.Brushes.WhiteSmoke,
                    CornerRadius = new CornerRadius(5),
                    BorderThickness = new Thickness(1),
                    BorderBrush = System.Windows.Media.Brushes.Gray,
                    Margin = new Thickness(0, 5, 0, 5),
                    Padding = new Thickness(10)
                };

                StackPanel stepPanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    VerticalAlignment = VerticalAlignment.Center
                };

                CheckBox stepCheckBox = new CheckBox
                {
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(0, 0, 10, 0)
                };
                stepPanel.Children.Add(stepCheckBox);

                TextBlock stepTextBlock = new TextBlock
                {
                    Text = $"Step {stepIndex}: {step}",
                    FontSize = 16,
                    FontWeight = FontWeights.Bold,
                    Foreground = System.Windows.Media.Brushes.Black,
                    VerticalAlignment = VerticalAlignment.Center
                };
                stepPanel.Children.Add(stepTextBlock);

                stepBorder.Child = stepPanel;
                RecipeDetailsStackPanel.Children.Add(stepBorder);
                stepIndex++;
            }
        }




        private void BackToListButton_Click(object sender, RoutedEventArgs e)
        {
            // Create an instance of the DisplayRecipe window
            DisplayRecipe displayRecipeWindow = new DisplayRecipe();

            // Show the DisplayRecipe window
            displayRecipeWindow.Show();

            // Close the current RecipeDetailsWindow
            this.Close();
        }

        private void MainMenuButton_Click(object sender, RoutedEventArgs e)
        {
            // Create an instance of the MainWindow
            MainWindow mainWindow = new MainWindow();

            // Show the MainWindow
            mainWindow.Show();

            // Close the current RecipeDetailsWindow
            this.Close();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}