﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace RecipeAppWPF
{
    public partial class RecipeDetailsWindow : Window
    {
        public RecipeDetailsWindow(Recipe recipe)
        {
            InitializeComponent();
            LoadRecipeDetails(recipe);
            WindowState = WindowState.Maximized;
        }

        //code attribution
        //this code was taken from: https://learn.microsoft.com/en-us/visualstudio/data-tools/display-related-data-in-wpf-applications?view=vs-2022

        private void LoadRecipeDetails(Recipe recipe)
        {
            // Clear previous content
            RecipeDetailsStackPanel.Children.Clear();

            // Display the name of the recipe
            TextBlock recipeNameTextBlock = new TextBlock
            {
                Text = recipe.Name,
                FontSize = 24,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black,
                TextAlignment = TextAlignment.Center,
                Margin = new Thickness(0, 20, 0, 20),
                TextDecorations = TextDecorations.Underline
            };

            RecipeDetailsStackPanel.Children.Add(recipeNameTextBlock);

            // Display the number of ingredients
            TextBlock ingredientCountTextBlock = new TextBlock
            {
                Text = $"Ingredients ({recipe.Ingredients.Count}):",
                FontSize = 20,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black,
                Margin = new Thickness(0, 10, 0, 10),
                TextDecorations = TextDecorations.Underline
            };
            RecipeDetailsStackPanel.Children.Add(ingredientCountTextBlock);

            // Display ingredient details
            foreach (var ingredient in recipe.Ingredients)
            {
                Border ingredientBorder = new Border
                {
                    Background = Brushes.WhiteSmoke,
                    CornerRadius = new CornerRadius(5),
                    BorderThickness = new Thickness(1),
                    BorderBrush = Brushes.Gray,
                    Margin = new Thickness(0, 5, 0, 5),
                    Padding = new Thickness(10)
                };

                StackPanel ingredientPanel = new StackPanel
                {
                    Orientation = Orientation.Vertical
                };

                TextBlock ingredientNameTextBlock = new TextBlock
                {
                    Text = ingredient.Name,
                    FontSize = 18,
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.Black,
                    Margin = new Thickness(0, 0, 0, 5)
                };
                ingredientPanel.Children.Add(ingredientNameTextBlock);

                TextBlock ingredientDetailsTextBlock = new TextBlock
                {
                    Text = $"Measurement: {ingredient.Measurement} {ingredient.Unit}, Calories: {ingredient.Calories}, Food Group: {ingredient.FoodGroup}",
                    FontSize = 16,
                    Foreground = Brushes.Black,
                    Margin = new Thickness(0, 0, 0, 5)
                };
                ingredientPanel.Children.Add(ingredientDetailsTextBlock);

                ingredientBorder.Child = ingredientPanel;
                RecipeDetailsStackPanel.Children.Add(ingredientBorder);
            }

            // Calculate total calories
            int totalCalories = recipe.Ingredients.Sum(i => i.Calories);

            // Display total calories
            TextBlock totalCaloriesTextBlock = new TextBlock
            {
                Text = $"Total Calories: {totalCalories}",
                FontSize = 18,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black,
                Margin = new Thickness(0, 20, 0, 5)
            };
            RecipeDetailsStackPanel.Children.Add(totalCaloriesTextBlock);

            // Display additional calorie range information based on total calories
            TextBlock calorieRangeTextBlock = new TextBlock
            {
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 5, 0, 20),
                TextWrapping = TextWrapping.Wrap
            };

            if (totalCalories < 50)
            {
                calorieRangeTextBlock.Text = "Calorie Range: Below 50 calories\nThis range is ideal for very light snacks or condiments, such as a small piece of celery or a single serving of low-calorie dip.";
                calorieRangeTextBlock.Foreground = Brushes.Green; // Adjust color as desired
            }
            else if (totalCalories >= 50 && totalCalories <= 100)
            {
                calorieRangeTextBlock.Text = "Calorie Range: 50-100 calories\nThis range is suitable for light snacks or condiments, such as a small piece of fruit or a tablespoon of peanut butter.";
                calorieRangeTextBlock.Foreground = Brushes.Green;
            }
            else if (totalCalories > 100 && totalCalories <= 200)
            {
                calorieRangeTextBlock.Text = "Calorie Range: 100-200 calories\nThis range is typical for small meals or larger snacks, like a yogurt cup or a slice of whole-grain bread with toppings.";
                calorieRangeTextBlock.Foreground = Brushes.Blue;
            }
            else if (totalCalories > 200 && totalCalories <= 300)
            {
                calorieRangeTextBlock.Text = "Calorie Range: 200-300 calories\nFalling within the range of a moderate snack or smaller meal, examples include a salad with lean protein or a sandwich on whole wheat bread.";
                calorieRangeTextBlock.Foreground = Brushes.Orange;
            }
            else if (totalCalories > 300)
            {
                calorieRangeTextBlock.Text = "Calorie Range: 300+ calories\nThis range accommodates larger meals, such as a hearty bowl of pasta with sauce, a grilled chicken breast with vegetables, or a balanced dinner plate with starch, protein, and vegetables. Exceeding 300 calories per serving may lead to higher caloric intake than recommended for a single meal, potentially affecting overall dietary balance and health.";
                calorieRangeTextBlock.Foreground = Brushes.Red;
            }

      


            RecipeDetailsStackPanel.Children.Add(calorieRangeTextBlock);

            // Display the number of steps
            TextBlock stepCountTextBlock = new TextBlock
            {
                Text = $"Steps ({recipe.Steps.Count}):",
                FontSize = 20,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black,
                Margin = new Thickness(0, 20, 0, 10),
                TextDecorations = TextDecorations.Underline
            };
            RecipeDetailsStackPanel.Children.Add(stepCountTextBlock);

            // Display each step with a checkbox
            int stepIndex = 1;
            foreach (var step in recipe.Steps)
            {
                Border stepBorder = new Border
                {
                    Background = Brushes.WhiteSmoke,
                    CornerRadius = new CornerRadius(5),
                    BorderThickness = new Thickness(1),
                    BorderBrush = Brushes.Gray,
                    Margin = new Thickness(0, 5, 0, 5),
                    Padding = new Thickness(10)
                };

                StackPanel stepPanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    VerticalAlignment = VerticalAlignment.Center
                };

                CheckBox stepCheckBox = new CheckBox
                {
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(0, 0, 10, 0)
                };
                stepPanel.Children.Add(stepCheckBox);

                TextBlock stepTextBlock = new TextBlock
                {
                    Text = $"Step {stepIndex}: {step}",
                    FontSize = 16,
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.Black,
                    VerticalAlignment = VerticalAlignment.Center
                };
                stepPanel.Children.Add(stepTextBlock);

                stepBorder.Child = stepPanel;
                RecipeDetailsStackPanel.Children.Add(stepBorder);
                stepIndex++;
            }
        }





        private void BackToListButton_Click(object sender, RoutedEventArgs e)
        {
            // Create an instance of the DisplayRecipe window
            DisplayRecipe displayRecipeWindow = new DisplayRecipe();

            // Show the DisplayRecipe window
            displayRecipeWindow.Show();

            // Close the current RecipeDetailsWindow
            this.Close();
        }

        private void MainMenuButton_Click(object sender, RoutedEventArgs e)
        {
            // Create an instance of the MainWindow
            MainWindow mainWindow = new MainWindow();

            // Show the MainWindow
            mainWindow.Show();

            // Close the current RecipeDetailsWindow
            this.Close();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}