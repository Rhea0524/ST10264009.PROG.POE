﻿using System.Collections.Generic;
using System.Windows;

namespace RecipeAppWPF
{
    public partial class MainWindow : Window
    {
        private List<Recipe> savedRecipes = new List<Recipe>(); // List to store saved recipes

        public MainWindow()
        {
            InitializeComponent();
            InitializeEvents(); // Method to initialize event handlers
            WindowState = WindowState.Maximized; // Set window state to maximized upon initialization
        }

        // Method to initialize event handlers for buttons
        private void InitializeEvents()
        {
            // Attach event handlers to respective buttons
            EnterRecipeDetailsButton.Click += EnterRecipeDetailsButton_Click;
            DisplayRecipeButton.Click += DisplayRecipeButton_Click;
            ScaleRecipeButton.Click += ScaleRecipeButton_Click;
            ResetQuantitiesButton.Click += ResetQuantitiesButton_Click;
            ClearDataButton.Click += ClearDataButton_Click;
            FoodGroupsButton.Click += FoodGroupsButton_Click;
            CaloriesButton.Click += CaloriesButton_Click;
            ExitButton.Click += ExitButton_Click;
            FilterButton.Click += FilterButton_Click;
        }

        // Event handler for "Enter Recipe Details" button click
        private void EnterRecipeDetailsButton_Click(object sender, RoutedEventArgs e)
        {
            // Hide the main window while showing the EnterRecipeDetailsWindow
            this.Hide();
            EnterRecipeDetailsWindow enterRecipeDetailsWindow = new EnterRecipeDetailsWindow();
            // Hook up Closed event to show the main window again when EnterRecipeDetailsWindow is closed
            enterRecipeDetailsWindow.Closed += (s, args) => this.Show();
            enterRecipeDetailsWindow.Show();
        }

        // Event handler for "Display Recipe" button click
        private void DisplayRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Open the DisplayRecipe window
            DisplayRecipe displayRecipeWindow = new DisplayRecipe();
            displayRecipeWindow.Show();
        }

        // Event handler for "Scale Recipe" button click
        private void ScaleRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Open the ScaleRecipe window
            ScaleRecipe scaleRecipeWindow = new ScaleRecipe();
            scaleRecipeWindow.Show();
        }

        // Event handler for "Reset Quantities" button click
        private void ResetQuantitiesButton_Click(object sender, RoutedEventArgs e)
        {
            // Open the ResetQuantities window
            ResetQuantities resetQuantitiesWindow = new ResetQuantities();
            resetQuantitiesWindow.Show();
        }

        // Event handler for "Clear Data" button click
        private void ClearDataButton_Click(object sender, RoutedEventArgs e)
        {
            // Open the ClearData window
            ClearData clearDataWindow = new ClearData();
            clearDataWindow.Show();
        }

        // Event handler for "Food Groups Info" button click
        private void FoodGroupsButton_Click(object sender, RoutedEventArgs e)
        {
            // Open the FoodGroupsInfo window
            FoodGroupsInfo foodGroupsInfoWindow = new FoodGroupsInfo();
            foodGroupsInfoWindow.Show();
        }

        // Event handler for "Calories Info" button click
        private void CaloriesButton_Click(object sender, RoutedEventArgs e)
        {
            // Open the CaloriesInfo window
            CaloriesInfo caloriesInfoWindow = new CaloriesInfo();
            caloriesInfoWindow.Show();
        }

        // Event handler for "Exit" button click
        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            // Display a farewell message and close the application
            MessageBox.Show("Thank you for using Recipe Realm", "Goodbye", MessageBoxButton.OK, MessageBoxImage.Information);
            Application.Current.Shutdown();
        }

        // Event handler for "Filter" button click
        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            // Create a new FilterWindow instance to gather filtering criteria
            FilterWindow filterWindow = new FilterWindow(RecipeManager.recipes);

            // Show the FilterWindow as a dialog
            bool? result = filterWindow.ShowDialog();

            // Optionally, handle the result if needed
            if (result == true)
            {
                // Perform actions based on the filtering result
                // For example, update the displayed recipes based on the filter criteria
            }
        }

    }
}
