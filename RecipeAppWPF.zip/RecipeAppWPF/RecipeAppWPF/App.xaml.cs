﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace RecipeAppWPF
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        // Define recipeList as a static variable accessible throughout the application
        public static List<Recipe> recipeList = new List<Recipe>();
    }
}
