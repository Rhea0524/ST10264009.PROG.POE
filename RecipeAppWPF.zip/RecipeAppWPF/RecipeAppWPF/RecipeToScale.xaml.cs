﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace RecipeAppWPF
{
    public partial class RecipeToScale : Window
    {
        private Recipe selectedRecipe;
        private bool isScaled = false; // Flag to track whether the recipe has been scaled

        public RecipeToScale(Recipe recipe)
        {
            InitializeComponent();
            selectedRecipe = recipe;
            LoadRecipeDetails(recipe);
            LoadScaleOptions();
            WindowState = WindowState.Maximized;
        }

        private void LoadRecipeDetails(Recipe recipe)
        {
            // Clear existing children
            RecipeDetailsStackPanel.Children.Clear();

            // Display the name of the recipe
            TextBlock recipeNameTextBlock = new TextBlock
            {
                Text = $"Name: {recipe.Name}",
                FontSize = 20,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black,
                Margin = new Thickness(0, 5, 0, 5),
                TextDecorations = TextDecorations.Underline
            };

            RecipeDetailsStackPanel.Children.Add(recipeNameTextBlock);

            // Display the number of ingredients
            TextBlock ingredientCountTextBlock = new TextBlock
            {
                Text = $"Number of Ingredients: {recipe.Ingredients.Count}",
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black,
                Margin = new Thickness(0, 5, 0, 5)
            };
            RecipeDetailsStackPanel.Children.Add(ingredientCountTextBlock);

            // Display ingredient details
            TextBlock ingredientDetailsHeading = new TextBlock
            {
                Text = "Ingredient Details:",
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black,
                Margin = new Thickness(0, 10, 0, 5),
                TextDecorations = TextDecorations.Underline
            };
            RecipeDetailsStackPanel.Children.Add(ingredientDetailsHeading);

            foreach (var ingredient in recipe.Ingredients)
            {
                StackPanel ingredientPanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    Margin = new Thickness(0, 5, 0, 5)
                };

                TextBlock ingredientTextBlock = new TextBlock
                {
                    Text = $"Ingredient: {ingredient.Name}, Measurement: {ingredient.Measurement} {ingredient.Unit}, Calories: {ingredient.Calories}, Food Group: {ingredient.FoodGroup}",
                    FontSize = 16,
                    FontWeight = FontWeights.Normal,
                    Foreground = Brushes.Black,
                    Margin = new Thickness(0, 5, 0, 5)
                };
                ingredientPanel.Children.Add(ingredientTextBlock);

                RecipeDetailsStackPanel.Children.Add(ingredientPanel);
            }

            // Display the number of steps
            TextBlock stepCountTextBlock = new TextBlock
            {
                Text = $"Number of Steps: {recipe.Steps.Count}",
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black,
                Margin = new Thickness(0, 10, 0, 5),
                TextDecorations = TextDecorations.Underline
            };
            RecipeDetailsStackPanel.Children.Add(stepCountTextBlock);

            // Display each step
            int stepIndex = 1;
            foreach (var step in recipe.Steps)
            {
                TextBlock stepTextBlock = new TextBlock
                {
                    Text = $"Step {stepIndex}: {step}",
                    FontSize = 16,
                    FontWeight = FontWeights.Normal,
                    Foreground = Brushes.Black,
                    Margin = new Thickness(0, 5, 0, 5)
                };
                RecipeDetailsStackPanel.Children.Add(stepTextBlock);
                stepIndex++;
            }
        }

        private void LoadScaleOptions()
        {
            ScaleComboBox.Items.Clear(); // Clear existing items
            string[] scaleOptions = { "0.5", "2", "3" }; // Add scale options for 2 and 3
            ScaleComboBox.ItemsSource = scaleOptions;
        }

        private void ScaleRecipe(double scale)
        {
            if (!isScaled) // Check if the recipe has not been scaled already
            {
                if (scale == 0.5 || scale == 2 || scale == 3) // Check if scale value is 0.5, 2, or 3
                {
                    foreach (var ingredient in selectedRecipe.Ingredients)
                    {
                        // Scale the measurement
                        ingredient.Measurement *= scale;

                        // Find the measurement text block in the UI
                        foreach (var child in RecipeDetailsStackPanel.Children)
                        {
                            if (child is StackPanel ingredientPanel)
                            {
                                foreach (var textBlock in ingredientPanel.Children)
                                {
                                    if (textBlock is TextBlock tb && tb.Text.Contains(ingredient.Name))
                                    {
                                        // Update the measurement text block
                                        string[] parts = tb.Text.Split(',');
                                        for (int i = 0; i < parts.Length; i++)
                                        {
                                            if (parts[i].Contains("Measurement:"))
                                            {
                                                // Update measurement value
                                                parts[i] = $"Measurement: {ingredient.Measurement} {ingredient.Unit}";
                                                // Update text and color
                                                tb.Text = string.Join(",", parts);
                                                tb.Foreground = Brushes.Red;
                                                // Display scaled successfully message
                                                MessageBox.Show("Recipe scaled successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    isScaled = true; // Set the flag to indicate that the recipe has been scaled
                }
                else
                {
                    MessageBox.Show("Invalid scale value. Please select a valid scale value.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Recipe already scaled. Cannot scale again.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ScaleButton_Click(object sender, RoutedEventArgs e)
        {
            if (ScaleComboBox.SelectedItem != null)
            {
                string selectedScale = ScaleComboBox.SelectedItem.ToString();
                // Remove any spaces and replace the comma with a dot if present (for cultures where comma is used as a decimal separator)
                selectedScale = selectedScale.Replace(" ", "").Replace(',', '.');

                if (double.TryParse(selectedScale, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double scaleValue))
                {
                    ScaleRecipe(scaleValue);
                }
                else
                {
                    MessageBox.Show("Failed to parse scale value.");
                }
            }
            else
            {
                MessageBox.Show("No scale selected.");
            }
        }

        private void MainMenuButton_Click(object sender, RoutedEventArgs e)
        {
            // Go back to the main menu
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }
    }
}
