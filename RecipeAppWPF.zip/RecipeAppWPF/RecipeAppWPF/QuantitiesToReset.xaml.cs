﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace RecipeAppWPF
{
    public partial class QuantitiesToReset : Window
    {
        private Recipe selectedRecipe;

        public QuantitiesToReset(Recipe recipe)
        {
            InitializeComponent();
            selectedRecipe = recipe;
            WindowState = WindowState.Maximized;

            // Call the method to load and display the scaled recipe details
            LoadRecipeDetails(selectedRecipe);
        }

        private void LoadRecipeDetails(Recipe recipe)
        {
            // Display the name of the recipe
            TextBlock recipeNameTextBlock = new TextBlock
            {
                Text = $"Name: {recipe.Name}",
                FontSize = 20,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black,
                Margin = new Thickness(0, 5, 0, 5),
                TextDecorations = TextDecorations.Underline
            };

            ResetRecipeDetailsStackPanel.Children.Add(recipeNameTextBlock);

            // Display the number of ingredients
            TextBlock ingredientCountTextBlock = new TextBlock
            {
                Text = $"Number of Ingredients: {recipe.Ingredients.Count}",
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black,
                Margin = new Thickness(0, 5, 0, 5)
            };
            ResetRecipeDetailsStackPanel.Children.Add(ingredientCountTextBlock);

            // Display ingredient details
            TextBlock ingredientDetailsHeading = new TextBlock
            {
                Text = "Ingredient Details:",
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black,
                Margin = new Thickness(0, 10, 0, 5),
                TextDecorations = TextDecorations.Underline
            };
            ResetRecipeDetailsStackPanel.Children.Add(ingredientDetailsHeading);

            foreach (var ingredient in recipe.Ingredients)
            {
                StackPanel ingredientPanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    Margin = new Thickness(0, 5, 0, 5)
                };

                TextBlock ingredientTextBlock = new TextBlock
                {
                    Text = $"Ingredient: {ingredient.Name}, Measurement: {ingredient.Measurement} {ingredient.Unit}, Calories: {ingredient.Calories}, Food Group: {ingredient.FoodGroup}",
                    FontSize = 16,
                    FontWeight = FontWeights.Normal,
                    Foreground = Brushes.Black,
                    Margin = new Thickness(0, 5, 0, 5)
                };
                ingredientPanel.Children.Add(ingredientTextBlock);

                ResetRecipeDetailsStackPanel.Children.Add(ingredientPanel);
            }

            // Display the number of steps
            TextBlock stepCountTextBlock = new TextBlock
            {
                Text = $"Number of Steps: {recipe.Steps.Count}",
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black,
                Margin = new Thickness(0, 10, 0, 5),
                TextDecorations = TextDecorations.Underline
            };
            ResetRecipeDetailsStackPanel.Children.Add(stepCountTextBlock);

            // Display each step
            int stepIndex = 1;
            foreach (var step in recipe.Steps)
            {
                TextBlock stepTextBlock = new TextBlock
                {
                    Text = $"Step {stepIndex}: {step}",
                    FontSize = 16,
                    FontWeight = FontWeights.Normal,
                    Foreground = Brushes.Black,
                    Margin = new Thickness(0, 5, 0, 5)
                };
                ResetRecipeDetailsStackPanel.Children.Add(stepTextBlock);
                stepIndex++;
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            // Navigate back to the previous window
            Close();
        }

        private void EnterNewRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Open the window to enter a new recipe
            EnterRecipeDetailsWindow enterRecipeDetailsWindow = new EnterRecipeDetailsWindow();
            enterRecipeDetailsWindow.Show();
            Close(); // Close the current window
        }

        private void SelectRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Check if a recipe is selected in the data grid
            if (RecipeDataGrid.SelectedItem != null && RecipeDataGrid.SelectedItem is Recipe selectedRecipe)
            {
                // Create a new instance of the QuantitiesToReset window with the selected recipe
                QuantitiesToReset quantitiesToResetWindow = new QuantitiesToReset(selectedRecipe);

                // Show the QuantitiesToReset window
                quantitiesToResetWindow.Show();

                // Close the current window
                Close();
            }
            else
            {
                // Display an error message if no recipe is selected
                MessageBox.Show("Please select a recipe to reset quantities.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            // Reset the measurement values of all ingredients to their original values
            foreach (var ingredient in selectedRecipe.Ingredients)
            {
                // Store the original measurement value
                string originalMeasurement = ingredient.Measurement.ToString();


                // Call the ResetMeasurement method of Ingredient class
                ingredient.ResetMeasurement();

                // Find the TextBlock displaying the ingredient details
                foreach (var child in ResetRecipeDetailsStackPanel.Children)
                {
                    if (child is StackPanel ingredientPanel)
                    {
                        foreach (var textBlock in ingredientPanel.Children)
                        {
                            if (textBlock is TextBlock ingredientTextBlock)
                            {
                                // Check if the TextBlock contains the original measurement value
                                if (ingredientTextBlock.Text.Contains(originalMeasurement))
                                {
                                    // Update the measurement text and color to red
                                    ingredientTextBlock.Text = $"Ingredient: {ingredient.Name}, Measurement: {ingredient.Measurement.ToString()} {ingredient.Unit}, Calories: {ingredient.Calories}, Food Group: {ingredient.FoodGroup}";
                                    ingredientTextBlock.Foreground = Brushes.Red;
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            // Display a message indicating that quantities have been reset
            MessageBox.Show("Recipe quantities reset successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
        }



        private void MainMenuButton_Click(object sender, RoutedEventArgs e)
        {
            // Go back to the main menu
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }
    }
}
