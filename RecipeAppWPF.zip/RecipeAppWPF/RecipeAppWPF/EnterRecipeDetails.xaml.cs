﻿using RecipeAppWPF;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace RecipeAppWPF
{
    public delegate void RecipeValidationHandler(bool isValid);
    public delegate void CaloriesExceededNotificationHandler(string message);

    public partial class EnterRecipeDetailsWindow : Window
    {
        private int _ingredientCount;
        private int _stepCount;

        public EnterRecipeDetailsWindow()
        {
            InitializeComponent();
            WindowState = WindowState.Maximized; // Open the Enter Recipe Details window in full-screen mode
        }

        private bool CheckCaloriesExceeded(bool isValid, CaloriesExceededNotificationHandler notificationHandler)
        {
            if (isValid)
            {
                int totalCalories = 0;

                // Iterate through each ingredient and sum up the calories
                foreach (var item in IngredientItemsControl.Items)
                {
                    if (item is WrapPanel wrapPanel)
                    {
                        foreach (var child in wrapPanel.Children)
                        {
                            if (child is TextBox textBox)
                            {
                                if (textBox.Name == "CaloriesTextBox")
                                {
                                    if (int.TryParse(textBox.Text, out int calories))
                                    {
                                        totalCalories += calories;
                                    }
                                }
                            }
                        }
                    }
                }

                // Check if total calories exceed 300
                if (totalCalories > 300)
                {
                    notificationHandler?.Invoke("Warning: This recipe exceeds 300 calories.");
                    return true; // Calories exceeded
                }
            }

            return false; // Calories within limit or validation failed
        }

        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender == NextButton1)
            {
                if (string.IsNullOrWhiteSpace(RecipeNameTextBox.Text))
                {
                    MessageBox.Show("Please fill out the recipe name.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                RecipeDetailsPanel.Visibility = Visibility.Collapsed;
                IngredientsPanel.Visibility = Visibility.Visible;
            }
            else if (sender == NextButton2)
            {
                if (int.TryParse(IngredientCountTextBox.Text, out _ingredientCount) && _ingredientCount > 0)
                {
                    IngredientsPanel.Visibility = Visibility.Collapsed;
                    IngredientDetailsPanel.Visibility = Visibility.Visible;

                    // Wrap the call to CheckCaloriesExceeded using a lambda expression
                    PopulateIngredientDetails((isValid) => CheckCaloriesExceeded(isValid, NotifyCaloriesExceeded));
                }
                else
                {
                    MessageBox.Show("Please enter a valid number of ingredients.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else if (sender == NextButton3)
            {
                IngredientDetailsPanel.Visibility = Visibility.Collapsed;
                RecipeStepCountPanel.Visibility = Visibility.Visible;
            }
            else if (sender == NextButton4)
            {
                if (int.TryParse(NumberOfStepsTextBox.Text, out _stepCount) && _stepCount > 0)
                {
                    RecipeStepCountPanel.Visibility = Visibility.Collapsed;
                    StepInputPanel.Visibility = Visibility.Visible;
                    PopulateStepDetails(); // Call to generate text boxes for step descriptions
                }
                else
                {
                    MessageBox.Show("Please enter a valid number of steps.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            // Add more cases as needed
        }

        private void NextStepButton_Click(object sender, RoutedEventArgs e)
        {
            // Validate the input for the number of steps
            if (int.TryParse(NumberOfStepsTextBox.Text, out _stepCount) && _stepCount > 0)
            {
                // Proceed to the step input panel
                RecipeStepCountPanel.Visibility = Visibility.Collapsed;
                StepInputPanel.Visibility = Visibility.Visible;
                PopulateStepDetails(); // Call to generate text boxes for step descriptions
            }
            else
            {
                // Display an error message if the input is invalid
                MessageBox.Show("Please enter a valid number of steps.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            // Assuming this window was opened from MainWindow
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }

        private void PopulateIngredientDetails(RecipeValidationHandler validationHandler)
        {
            string[] foodGroups = { "Starchy foods", "Vegetables and fruits", "Dry beans, peas, lentils and soya", "Chicken, fish, meat and eggs", "Milk and dairy products", "Fats and oil", "Water" };
            string[] unitOptions = { "kg", "g", "mg", "bowl", "cup", "l", "ml", "teaspoon", "tablespoon" };

            IngredientItemsControl.Items.Clear();
            for (int i = 0; i < _ingredientCount; i++)
            {
                var wrapPanel = new WrapPanel { Margin = new Thickness(0, 5, 0, 5) };

                var nameLabel = new TextBlock { Text = "Name:", Margin = new Thickness(5), FontSize = 16, FontWeight = FontWeights.Bold };
                var nameBox = new TextBox { Name = "NameTextBox", Margin = new Thickness(5), Width = 150, FontSize = 16 };

                var measurementLabel = new TextBlock { Text = "Measurement:", Margin = new Thickness(5), FontSize = 16, FontWeight = FontWeights.Bold };
                var measurementBox = new TextBox { Name = "MeasurementTextBox", Margin = new Thickness(5), Width = 100, FontSize = 16 };

                // Add event handler for text changed to enforce numeric input and greater than 0
                measurementBox.TextChanged += (sender, e) =>
                {
                    if (!int.TryParse(measurementBox.Text, out int result) || result <= 0)
                    {
                        MessageBox.Show("Please enter a valid number greater than 0 for measurement.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        measurementBox.Text = ""; // Clear invalid input
                    }
                };

                var unitLabel = new TextBlock { Text = "Unit:", Margin = new Thickness(5), FontSize = 16, FontWeight = FontWeights.Bold };
                var unitComboBox = new ComboBox { Name = "UnitComboBox", Margin = new Thickness(5), Width = 100, FontSize = 16, ItemsSource = unitOptions };

                var caloriesLabel = new TextBlock { Text = "Calories:", Margin = new Thickness(5), FontSize = 16, FontWeight = FontWeights.Bold };
                var caloriesBox = new TextBox { Name = "CaloriesTextBox", Margin = new Thickness(5), Width = 100, FontSize = 16 };

                // Add event handler for text changed to enforce numeric input and greater than 0
                caloriesBox.TextChanged += (sender, e) =>
                {
                    if (!int.TryParse(caloriesBox.Text, out int result) || result <= 0)
                    {
                        MessageBox.Show("Please enter a valid number greater than 0 for calories.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        caloriesBox.Text = ""; // Clear invalid input
                    }
                };

                var foodGroupLabel = new TextBlock { Text = "Food Group:", Margin = new Thickness(5), FontSize = 16, FontWeight = FontWeights.Bold };
                var foodGroupComboBox = new ComboBox { Margin = new Thickness(5), Width = 150, FontSize = 16 };
                foodGroupComboBox.ItemsSource = foodGroups;

                wrapPanel.Children.Add(nameLabel);
                wrapPanel.Children.Add(nameBox);
                wrapPanel.Children.Add(measurementLabel);
                wrapPanel.Children.Add(measurementBox);
                wrapPanel.Children.Add(unitLabel);
                wrapPanel.Children.Add(unitComboBox);
                wrapPanel.Children.Add(caloriesLabel);
                wrapPanel.Children.Add(caloriesBox);
                wrapPanel.Children.Add(foodGroupLabel);
                wrapPanel.Children.Add(foodGroupComboBox);

                IngredientItemsControl.Items.Add(wrapPanel);
            }

            // Call the validation handler after populating ingredient details
            validationHandler?.Invoke(false);
        }

        private void NotifyCaloriesExceeded(string message)
        {
            string explanation = "Exceeding 300 calories per serving may lead to higher caloric intake than recommended for a single meal, potentially affecting overall dietary balance and health.";
            MessageBox.Show($"{message}\n\n{explanation}", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        private void NextIngredientButton_Click(object sender, RoutedEventArgs e)
        {
            // Check if any fields are empty for each ingredient
            foreach (var item in IngredientItemsControl.Items)
            {
                if (item is WrapPanel wrapPanel)
                {
                    foreach (var child in wrapPanel.Children)
                    {
                        if (child is TextBox textBox && string.IsNullOrWhiteSpace(textBox.Text))
                        {
                            MessageBox.Show("Please fill in all fields for each ingredient.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                            return; // Stop processing if any field is empty
                        }
                    }
                }
            }

            // Check if calories exceed 300
            bool caloriesExceeded = CheckCaloriesExceeded(true, NotifyCaloriesExceeded);

            // Proceed to the next step
            IngredientDetailsPanel.Visibility = Visibility.Collapsed;
            RecipeStepCountPanel.Visibility = Visibility.Visible;
        }

        private void PopulateStepDetails()
        {
            StepItemsControl.Items.Clear();
            for (int i = 0; i < _stepCount; i++)
            {
                var panel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5) };

                var stepLabel = new TextBlock
                {
                    Text = $"Step {i + 1}:",
                    Margin = new Thickness(5),
                    FontSize = 16,
                    FontWeight = FontWeights.Bold
                };

                var stepBox = new TextBox
                {
                    Width = 300,
                    Margin = new Thickness(5),
                    FontSize = 16,
                    AcceptsReturn = true
                };

                panel.Children.Add(stepLabel);
                panel.Children.Add(stepBox);

                StepItemsControl.Items.Add(panel);
            }
        }



        private void SaveRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Save the recipe
            Recipe recipe = new Recipe(RecipeNameTextBox.Text);

            foreach (var item in IngredientItemsControl.Items)
            {
                if (item is WrapPanel wrapPanel)
                {
                    string name = "", unit = "", foodGroup = "";
                    double measurement = 0;
                    int calories = 0;

                    foreach (var child in wrapPanel.Children)
                    {
                        if (child is TextBox textBox)
                        {
                            switch (textBox.Name)
                            {
                                case "NameTextBox":
                                    name = textBox.Text;
                                    break;
                                case "MeasurementTextBox":
                                    if (!double.TryParse(textBox.Text, out measurement) || measurement <= 0)
                                    {
                                        MessageBox.Show("Please enter a valid measurement greater than 0 for ingredient: " + name, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                                        return; // Stop processing if measurement is invalid
                                    }
                                    break;
                                case "UnitComboBox":
                                    unit = textBox.Text; // Assuming you meant ComboBox, not TextBox
                                    break;
                                case "CaloriesTextBox":
                                    int.TryParse(textBox.Text, out calories);
                                    break;
                            }
                        }
                        else if (child is ComboBox comboBox)
                        {
                            foodGroup = comboBox.SelectedItem as string;
                        }
                    }

                    Ingredient ingredient = new Ingredient(name, measurement, unit, calories, foodGroup);
                    recipe.Ingredients.Add(ingredient);
                }
            }

            for (int i = 0; i < _stepCount; i++)
            {
                if (StepItemsControl.Items[i] is StackPanel stepPanel)
                {
                    foreach (var child in stepPanel.Children)
                    {
                        if (child is TextBox textBox)
                        {
                            recipe.Steps.Add(textBox.Text);
                        }
                    }
                }
            }

            // Add the recipe to the RecipeManager
            RecipeManager.AddRecipe(recipe);

            // Show a message box indicating that the recipe has been saved successfully
            MessageBox.Show("Recipe saved successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

            // Navigate back to the main window
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close(); // Close the current window
        }
    }
}