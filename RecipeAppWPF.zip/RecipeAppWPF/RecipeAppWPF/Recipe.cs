﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeAppWPF
{
    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<string> Steps { get; set; }
        public string FoodGroup { get; set; } // Add this property

        public Recipe(string name)
        {
            Name = name;
            Ingredients = new List<Ingredient>();
            Steps = new List<string>();
        }

        public void AddIngredient(Ingredient ingredient)
        {
            Ingredients.Add(ingredient);
        }

        public void AddStep(string step)
        {
            Steps.Add(step);
        }

        public int TotalCalories
        {
            get
            {
                return Ingredients.Sum(ingredient => ingredient.Calories);
            }
        }
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public double Measurement { get; set; } // Change this to a numeric type
        public double OriginalMeasurement { get; set; } // Store the original measurement value
        public string Unit { get; set; }
        public int Calories { get; set; }
        public string FoodGroup { get; set; }

        public Ingredient(string name, double measurement, string unit, int calories, string foodGroup)
        {
            Name = name;
            Measurement = measurement;
            OriginalMeasurement = measurement; // Store the original measurement value
            Unit = unit;
            Calories = calories;
            FoodGroup = foodGroup;
        }

        public void ResetMeasurement()
        {
            // Reset the measurement value to its original value
            Measurement = OriginalMeasurement;
        }
    }


}
