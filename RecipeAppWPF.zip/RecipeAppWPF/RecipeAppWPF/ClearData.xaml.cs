﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace RecipeAppWPF
{
    public partial class ClearData : Window
    {
        //code attribution
        //this code was taken from: https://www.reddit.com/r/learnprogramming/comments/5gz5ne/how_to_clear_values_in_a_datagrid_in_c_wpf/
        public ClearData()
        {
            InitializeComponent();

            // Set window state to maximized when initialized
            WindowState = WindowState.Maximized;

            // Call the method to load recipes when the window is created
            LoadRecipes();
        }

        // Method to load recipes into the DataGrid
        private void LoadRecipes()
        {
            // Retrieve the list of recipes from the RecipeManager
            var recipes = RecipeManager.GetAllRecipes();

            if (recipes == null || recipes.Count == 0)
            {
                // If there are no recipes, show a message and hide unnecessary controls
                NoRecipesBorder.Visibility = Visibility.Visible;
                RecipeDataGrid.Visibility = Visibility.Hidden;
                MainMenuButton.Visibility = Visibility.Collapsed; // Hide the main menu button when no recipes are displayed
            }
            else
            {
                // If there are recipes, hide the message and display the DataGrid
                NoRecipesBorder.Visibility = Visibility.Hidden;
                RecipeDataGrid.Visibility = Visibility.Visible;
                MainMenuButton.Visibility = Visibility.Visible; // Show the main menu button when recipes are displayed

                // Sort the recipes alphabetically by name
                recipes = recipes.OrderBy(recipe => recipe.Name).ToList();

                // Set the data context of the DataGrid to the sorted list of recipes
                RecipeDataGrid.ItemsSource = recipes;
            }
        }

        // Event handler for the "Select Recipe" button click
        private void SelectRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Get the selected recipe from the button's DataContext
            var button = sender as Button;
            var selectedRecipe = button?.DataContext as Recipe;

            if (selectedRecipe != null)
            {
                // Display a confirmation dialog to confirm deletion
                var result = MessageBox.Show("Are you sure you want to clear this recipe?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    // Remove the selected recipe from the data source
                    RecipeManager.RemoveRecipe(selectedRecipe);

                    // Reload the recipes in the DataGrid
                    LoadRecipes();
                }
            }
        }

        // Event handler for the Main Menu button click
        private void MainMenuButton_Click(object sender, RoutedEventArgs e)
        {
            // Instantiate the main window (MainWindow)
            MainWindow mainWindow = new MainWindow();
            // Show the main window
            mainWindow.Show();
            // Close the current window (ClearData window)
            this.Close();
        }

        // Event handler for the "Enter a New Recipe" button click
        private void EnterNewRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Open the EnterRecipeDetailsWindow to enter a new recipe
            EnterRecipeDetailsWindow enterRecipeDetailsWindow = new EnterRecipeDetailsWindow();
            enterRecipeDetailsWindow.ShowDialog();
        }

        // Event handler for the window loaded event
        private void ClearData_Loaded(object sender, RoutedEventArgs e)
        {
            // Add any additional logic you want to perform when the window is loaded here
        }

        // Event handler for the "Back" button click
        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            // Navigate back to the main window (MainWindow)
            MainWindow mainWindow = new MainWindow();
            // Show the main window
            mainWindow.Show();
            // Close the current window (ClearData window)
            this.Close();
        }
    }
}
