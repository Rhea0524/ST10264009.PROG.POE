﻿using System.Windows;

namespace RecipeAppWPF
{
    public partial class CaloriesInfo : Window
    {
        public CaloriesInfo()
        {
            InitializeComponent();

            // Set window state to maximized when initialized
            WindowState = WindowState.Maximized;
        }

        private void MainMenuButton_Click(object sender, RoutedEventArgs e)
        {
            // Instantiate a new MainWindow
            MainWindow mainWindow = new MainWindow();

            // Show the MainWindow
            mainWindow.Show();

            // Close the current CaloriesInfo window
            this.Close();
        }
    }
}
