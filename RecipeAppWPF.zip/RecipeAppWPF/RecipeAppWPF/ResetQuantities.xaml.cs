﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace RecipeAppWPF
{
    public partial class ResetQuantities : Window
    {
        public ResetQuantities()
        {
            InitializeComponent();
            LoadRecipes();
            WindowState = WindowState.Maximized;
        }

        private void LoadRecipes()
        {
            // Retrieve the list of recipes from the RecipeManager
            List<Recipe> recipes = RecipeManager.GetAllRecipes();

            if (recipes == null || recipes.Count == 0)
            {
                NoRecipesBorder.Visibility = Visibility.Visible;
                RecipeDataGrid.Visibility = Visibility.Hidden;
                MainMenuButton.Visibility = Visibility.Collapsed; // Hide the main menu button when no recipes are displayed
            }
            else
            {
                NoRecipesBorder.Visibility = Visibility.Hidden;
                RecipeDataGrid.Visibility = Visibility.Visible;
                MainMenuButton.Visibility = Visibility.Visible; // Show the main menu button when recipes are displayed

                // Sort the recipes alphabetically by name
                recipes = recipes.OrderBy(recipe => recipe.Name).ToList();

                // Set the data context of the DataGrid to the sorted list of recipes
                RecipeDataGrid.ItemsSource = recipes;
            }
        }

        private void SelectRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Get the selected recipe
            Button button = sender as Button;
            Recipe selectedRecipe = button.DataContext as Recipe;

            // Open the QuantitiesToReset window for the selected recipe
            QuantitiesToReset quantitiesToResetWindow = new QuantitiesToReset(selectedRecipe);
            quantitiesToResetWindow.Show();
            Close();
        }


        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            // Navigate back to the main window
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }

        private void EnterNewRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Open the EnterRecipeDetailsWindow to enter a new recipe
            EnterRecipeDetailsWindow enterRecipeDetailsWindow = new EnterRecipeDetailsWindow();
            enterRecipeDetailsWindow.Show();
            Close();
        }

        private void MainMenuButton_Click(object sender, RoutedEventArgs e)
        {
            // Open the main menu window
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            // Navigate back to the main window
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }
    }
}
